#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

void questionario();
void leitura();

#endif // HEADER_H_INCLUDED
